# Tugas Ke Dua 
Layout Dengan CSS seperti pada gambar dibwah ini :

![Alt text](https://raw.githubusercontent.com/PW-TI/Tugas-2/main/img/hasil.jpg?raw=true "Halaman Utama")
